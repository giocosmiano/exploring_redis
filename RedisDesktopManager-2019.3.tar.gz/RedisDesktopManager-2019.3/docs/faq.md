## Where is the connections config stored?
**Windows** `C:\Users\%Your user%\.rdm\connections.json`

**OS X** `$HOME/Library/Preferences/rdm/connections.json`

**Linux** `$HOME/.rdm/connections.json`

## What info is sent to developers when the app crashes?
You can find answer here [https://oops.redisdesktop.com/help/](https://oops.redisdesktop.com/help/)
