#pragma once

#include "basetestcase.h"

class TestAbstractKey : public BaseTestCase
{
    Q_OBJECT

private slots:
    void testValueToBinary();

};
